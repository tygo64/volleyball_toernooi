<!-- 
	Opdracht PM12 STAP 1 : Film Aanpassen
	Maak hier het formulier waarmee je een film kan aanpassen in de database. Let op: dit formulier is vrijwel identiek aan het formulier uit de vorige opdracht
-->

	
<h1>Boot Aanpassen</h1>
	<form name="BootToevoegenFormulier" action="" method="post">
		<label for="Naam">Naam:</label>
		<input type="text" id="Naam" name="Naam" value="<?php echo $Naam; ?>"/><?php echo $NaamErr; ?>
		<br />
		<label for="Omschrijving">Beschrijving:</label><br />
		<textarea rows="4" cols="50" id="Omschrijving" name="Omschrijving"><?php echo $Omschrijving; ?></textarea>
		<?php echo $OmschrijvingErr; ?>
		<br />		
		<label for="Bouwjaar">Bouwjaar:</label>
		<input type="text" id="Bouwjaar" name="Bouwjaar" maxlength="3" value="<?php echo $Bouwjaar; ?>" /><?php echo $BouwjaarErr; ?>
		<br />
		<?php
		$db = ConnectDB();
		try {
    $query = $db->prepare("SELECT * FROM Boten");
    $query->execute();
} catch(PDOException $e) {
    die("Error!: " . $e->getMessage());
}
echo '<label for="Merk">Merk:</label>';
echo '<select id="Merk" name="Merk">';
while ($data = $query->fetch(PDO::FETCH_ASSOC)) {
    echo '<option value="'.$data['Merk'].'">'.$data['Merk'].'  <br>';
}
echo '</select>';
		 ?> 
		<br />		
		<label for="Capaciteit">Capaciteit:</label>
		<input type="text" id="Capaciteit" name="Capaciteit" value="<?php echo $Capaciteit; ?>" />

		<br />
		<label for="Plaatje">Plaatje:</label>
		<input type="text" id="Plaatje" name="Plaatje" value="<?php echo $Plaatje; ?>" />
		<br />
		<label for="Prijs">Prijs:</label>
		<input type="text" id="Prijs" name="Prijs" value="<?php echo $Prijs; ?>" />
		<?php echo $PrijsErr; ?>
		<br />
		<?php
		$db = ConnectDB();
		try {
    $query = $db->prepare("SELECT * FROM soorten_boten");
    $query->execute();
} catch(PDOException $e) {
    die("Error!: " . $e->getMessage());
}
echo '<label for="SoortBootNr">Type:</label>';
echo '<select id="SoortBootNr" name="SoortBootNr">';
while ($data = $query->fetch(PDO::FETCH_ASSOC)) {
    echo '<option value="'.$data['SoortBootNr'].'">'.$data['Naam'].'<br>';
}
echo '</select>';
try {
    $query = $db->prepare("SELECT * FROM Locatie");
    $query->execute();
} catch(PDOException $e) {
    die("Error!: " . $e->getMessage());
}
echo '<label for="LocatieNr">Locatie:</label>';
echo '<select id="LocatieNr" name="LocatieNr">';
while ($data = $query->fetch(PDO::FETCH_ASSOC)) {
    echo '<option value="'.$data['LocatieNr'].'">'.$data['Naam'].'  <br>';
}
echo '</select>';
try {
    $query = $db->prepare("SELECT * FROM Boten");
    $query->execute();
} catch(PDOException $e) {
    die("Error!: " . $e->getMessage());
}
echo '<label for="Status">Status:</label>';
echo '<select id="Status" name="Status">';
while ($data = $query->fetch(PDO::FETCH_ASSOC)) {
    echo '<option value="'.$data['BootNr'].'">'.$data['Status'].'  <br>';
}
echo '</select>';
		 ?>

		<br />	
		<label for="Lengte">Lengte:</label>
		<input type="text" id="Lengte" name="Lengte" value="<?php echo $Lengte; ?>" />	
		 		<input type="submit" name="Aanpassen" value="Aanpassen!" />
	</form>
	<br />
