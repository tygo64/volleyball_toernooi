<?php
// beveiliging pagina voor niet geautoriseerde bezoekers
if(LoginCheck($pdo))
{
    // user is ingelogd
    if($_SESSION['level'] >= 5) //pagina alleen zichtbaar voor level 5 of hoger
    {
        //-------------code---------------//    
        
        if(isset($_GET['Action']))
        {
            //haalt de action op die bepaalt of de boot gewijzigd of verwijderd wordt
            $Action = $_GET['Action'];
            
            //switch die bepaalt wat er gebeurt wanneer de action Edit of Del is.
            switch($Action)
            {
                case 'Edit':

                            //init fields
                            $Naam = $Merk = $Bouwjaar = $Omschrijving = $Prijs = $Plaatje = $Status = $SoortBootNr = $LocatieNr = $Capaciteit = $Lengte = NULL;

                            //init error fields
                            $NaamErr = $MerkErr = $BouwjaarErr = $OmschrijvingErr = $PrijsErr = $PlaatjeErr = $StatusErr = NULL;
                            
                            //controleert of het formulier is ge-submit. LET OP: de knop moet Aanpassen heten
                            if(isset($_POST['Aanpassen']))
                            {    
                                //formulier is gesubmit 

                                $CheckOnErrors = false; // hulpvariabele voor het valideren van het formulier
                                
                                /* 
                                Valideer de gegevens weer op dezelfde manier als in opdracht 5.01, nadat je de gegevens middels een POST hebt ingelezen
                                */    

                                $Naam = $_POST["Naam"];
                                $Merk = $_POST["Merk"];
                                $Bouwjaar = $_POST['Bouwjaar'];
                                $Omschrijving = $_POST['Omschrijving'];
                                $Prijs = $_POST['Prijs'];
                                $Plaatje = $_POST['Plaatje'];
                                $Status = $_POST['Status'];
                                $SoortBootNr = $_POST['SoortBootNr'];
                                $LocatieNr = $_POST['LocatieNr'];
                                $Capaciteit = $_POST['Capaciteit'];
                                $Lengte = $_POST['Lengte'];
                                //BEGIN CONTROLES
                                //controleert het Naam veld
                                if(empty($Naam))
                                {
                                    $NaamErr = "dit veld is vereist";
                                    $CheckOnErrors = true;
                                }
                                
                                //controleert het Merk veld
                                if(empty($Merk))
                                {
                                    $MerkErr = "dit veld is vereist";
                                    $CheckOnErrors = true;
                                }

                                //controleert het Bouwjaar veld
                                if(empty($Bouwjaar))
                                {
                                    $BouwjaarErr = "dit veld is vereist";
                                    $CheckOnErrors = true;
                                }
                                
                                //controleert het Capaciteit veld
                                if(empty($Omschrijving))
                                {
                                    $OmschrijvingErr = "dit veld is vereist";
                                    $CheckOnErrors = true;
                                }
                                
                                //controleert het Jaar veld
                                if(empty($Prijs))
                                {
                                    $PrijsErr = "dit veld is vereist";
                                    $CheckOnErrors = true;
                                }
                                //controleert het Lengte veld
                                if(empty($Plaatje))
                                {
                                    $PlaatjeErr = "dit veld is vereist";
                                    $CheckOnErrors = true;
                                }
                                
                                //controleert het Prijs veld
                                if(empty($Status))
                                {
                                    $StatusErr = "dit veld is vereist";
                                    $CheckOnErrors = true;
                                }
                                //EINDE CONTROLE
                                
                                /* 
                                Controleer ook hier weer of er een validatie fout is ontstaan. Zo ja, dan krijgt de gebruiker het formulier weer te zien, zo nee, Dan gaan we de gegevens toevoegen aan de Database. Dit doen we door een prepared statement te maken waarmee je de gegevens van de boot middels een UPDATE in de database aanpast. Wanneer dit is gelukt krijgt de gebruiker hiervan een melding op het scherm
                                */
                                if($CheckOnErrors)
                                {
                                    //er zijn fouten geconstateerd
                                    require('./Forms/BootAanpassenForm.php');
                                }
                                else
                                {
                                    //formulier is succesvol gevalideerd

                                    //query opbouwen
                                    $parameters = array(':BootNr'=>$_GET['BootNr'],
                                                ':Naam'=>$Naam,
                                                ':Merk'=>$Merk,
                                                ':Bouwjaar'=>$Bouwjaar,
                                                ':Omschrijving'=>$Omschrijving,
                                                ':Prijs'=>$Prijs,
                                                ':Plaatje'=>$Plaatje,
                                                ':Status'=>$Status,
                                                ':SoortBootNr'=>$SoortBootNr,
                                                ':LocatieNr'=>$LocatieNr,
                                                ':Capaciteit'=>$Capaciteit,
                                                ':Lengte'=>$Lengte);

                                    $sth = $pdo->prepare('UPDATE boten SET Naam = :Naam, Merk = :Merk, Bouwjaar = :Bouwjaar, Omschrijving = :Omschrijving, Prijs = :Prijs, Plaatje = :Plaatje, Status = :Status, SoortBootNr = :SoortBootNr, LocatieNr = :LocatieNr, Capaciteit = :Capaciteit, Lengte = :Lengte  WHERE BootNr = :BootNr');
                        
                                    $sth->execute($parameters);
                                    
                                    echo "De bootgegevens zijn succesvol aangepast";
                                    RedirectNaarPagina(3,12);
                                }
                            }
                            else
                            {
                                //formulier is nog niet gesubmit
                                /*  
                                Omschrijving: maak een prepared statement waarmee je de gegevens van de Boot die gewijzigd moet worden ophaalt. Het BootNr dien je te verkrijgen uit de GET variabele zodat je de juiste gegevens er bij kan terugvinden
                                */
                                
                                $parameters = array(':BootNr'=>$_GET['BootNr']);

                                $sth = $pdo->prepare('SELECT * FROM boten WHERE BootNr = :BootNr');

                                $sth->execute($parameters);
                                $row = $sth->fetch();// rij fetchen

                                /*
                                Omschrijving: Zet de gegevens uit de database over naar de juiste variabelen zodat ze in het formulier bestand kunnen worden gebruikt. Roep vervolgens het formulier aan.
                                */

                                // overzetten naar juiste variabelen voor werking formulier
                                $Naam = $row["Naam"];
                                $Merk = $row["Merk"];
                                $Bouwjaar = $row['Bouwjaar'];
                                $Omschrijving = $row['Omschrijving'];
                                $Prijs = $row['Prijs'];
                                $Plaatje = $row['Plaatje'];
                                $Status = $row['Status'];
                                $SoortBootNr = $row['SoortBootNr'];
                                $LocatieNr = $row['LocatieNr'];
                                $Capaciteit = $row['Capaciteit'];
                                $Lengte = $row['Lengte'];
                        
                                require('./Forms/BootAanpassenForm.php');
                            }
                            break;
                case 'Del': 
                            $parameters = array(':BootNr'=>$_GET['BootNr']);
                            $sth = $pdo->prepare('SELECT COUNT(*) FROM reservering WHERE BootNr = :BootNr');
                            $sth->execute($parameters);
                            $count = $sth->fetchColumn();
                            //check of er nog reserveringen voor de boot zijn
                            if($count > 0) {
                                echo "Deze boot kan niet worden verwijderd omdat er nog reserveringen voor bestaan.";
                                RedirectNaarPagina(3,8);



                            }else {
                                //let op dat je altijd het BootNr meegeeft aan de DELETE!!!!!!
                                $parameters = array(':BootNr'=>$_GET['BootNr']);

                            $sth = $pdo->prepare('DELETE FROM boten WHERE BootNr = :BootNr');

                            $sth->execute($parameters);

                            echo "De boot is verwijderd";
                            RedirectNaarPagina(3,12);
                            break;


            }}
        }
        else
        {
            echo '<a href="./index.php?PaginaNr=7'.'">Boot Toevoegen</a>';

            $sth = $pdo->prepare('SELECT b.*, s.Naam AS SoortNaam, l.Naam AS LocatieNaam FROM boten b, soorten_boten s, locatie l WHERE b.LocatieNr = l.LocatieNr AND b.SoortBootNr = s.SoortBootNr');
            $sth->execute();

            echo '<table border="0">';
            echo '<tr>';
            echo    '<th>Plaatje</th>';
            echo    '<td>Naam</td>';
            echo    '<td>Type</td>';
            echo    '<td>Merk</td>';
            echo    '<td>Bouwjaar</td>';
            echo    '<td>Capaciteit</td>';
            echo    '<td>Locatie</td>';
            echo    '<td>Lengte</td>';
            echo    '<td>Prijs per uur</td>';
            echo '</tr>';

            while($row = $sth->fetch())
            {
                echo '<tr>';
                echo '<td rowspan="2"><img src="./images/'.$row['Plaatje'].'" alt="'.$row['Naam'].'"></td>';
                echo '<td>'.$row['Naam'].'</td>';
                echo '<td>'.$row['SoortNaam'].'</td>';
                echo '<td>'.$row['Merk'].'</td>';
                echo '<td>'.$row['Bouwjaar'].'</td>';
                echo '<td>'.$row['Capaciteit'].'</td>';
                echo '<td>'.$row['LocatieNaam'].'</td>';
                echo '<td>'.$row['Lengte'].' Meter'.'</td>';
                echo '<td>€ '.number_format($row['Prijs'], 2, ',', '').'</td>';                
                echo '</tr>';
                echo '<tr>';
                echo '<td colspan="6">'.$row['Omschrijving'].'</td>';

                // LET OP: pagina nr goed instellen , Boot ID meegeven , en Action aangeven als GET parameters
                echo '<td><a href="./index.php?PaginaNr=12&Action=Edit&BootNr='.$row['BootNr'].'">Aanpassen</a></td>';

                echo '<td><a href="./index.php?PaginaNr=12&Action=Del&BootNr='.$row['BootNr'].'">Verwijderen</a></td>';

                echo '</tr>';
            }
            echo '</table>';

        }
    }    else
    {
        $sth = $pdo->prepare('SELECT b.*, s.Naam AS SoortNaam, l.Naam AS LocatieNaam FROM boten b, soorten_boten s, locatie l WHERE b.LocatieNr = l.LocatieNr AND b.SoortBootNr = s.SoortBootNr');
        $sth->execute();

        echo '<table border="0">';
        echo '<tr>';
        echo    '<th>Plaatje</th>';
        echo    '<td>Naam</td>';
        echo    '<td>Type</td>';
        echo    '<td>Merk</td>';
        echo    '<td>Bouwjaar</td>';
        echo    '<td>Capaciteit</td>';
        echo    '<td>Locatie</td>';
        echo    '<td>Lengte</td>';
        echo    '<td>Prijs per uur</td>';
        echo '</tr>';

        while($row = $sth->fetch())
        {
            echo '<tr>';
            echo '<td rowspan="2"><img src="./images/'.$row['Plaatje'].'" alt="'.$row['Naam'].'"></td>';
            echo '<td>'.$row['Naam'].'</td>';
            echo '<td>'.$row['SoortNaam'].'</td>';
            echo '<td>'.$row['Merk'].'</td>';
            echo '<td>'.$row['Bouwjaar'].'</td>';
            echo '<td>'.$row['Capaciteit'].'</td>';
            echo '<td>'.$row['LocatieNaam'].'</td>';
            echo '<td>'.$row['Lengte'].' Meter'.'</td>';
            echo '<td>€ '.number_format($row['Prijs'], 2, ',', '').'</td>';                
            echo '</tr>';
            echo '<tr>';
            echo '<td colspan="8">'.$row['Omschrijving'].'</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
}
else
{
    $sth = $pdo->prepare('SELECT b.*, s.Naam AS SoortNaam, l.Naam AS LocatieNaam FROM boten b, soorten_boten s, locatie l WHERE b.LocatieNr = l.LocatieNr AND b.SoortBootNr = s.SoortBootNr');
    $sth->execute();

    echo '<table border="0">';
    echo '<tr>';
    echo    '<th>Plaatje</th>';
    echo    '<td>Naam</td>';
    echo    '<td>Type</td>';
    echo    '<td>Merk</td>';
    echo    '<td>Bouwjaar</td>';
    echo    '<td>Capaciteit</td>';
    echo    '<td>Locatie</td>';
    echo    '<td>Lengte</td>';
    echo    '<td>Prijs per uur</td>';
    echo '</tr>';

    while($row = $sth->fetch())
    {
        echo '<tr>';
        echo '<td rowspan="2"><img src="./images/'.$row['Plaatje'].'" alt="'.$row['Naam'].'"></td>';
        echo '<td>'.$row['Naam'].'</td>';
        echo '<td>'.$row['SoortNaam'].'</td>';
        echo '<td>'.$row['Merk'].'</td>';
        echo '<td>'.$row['Bouwjaar'].'</td>';
        echo '<td>'.$row['Capaciteit'].'</td>';
        echo '<td>'.$row['LocatieNaam'].'</td>';
        echo '<td>'.$row['Lengte'].' Meter'.'</td>';
        echo '<td>€ '.number_format($row['Prijs'], 2, ',', '').'</td>';                
        echo '</tr>';
        echo '<tr>';
        echo '<td colspan="8">'.$row['Omschrijving'].'</td>';
        echo '</tr>';
    }
    echo '</table>';
}
?>
