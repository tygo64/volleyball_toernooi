<?php
function login($Username, $password, $pdo)
{
    // Prepare and execute the statement to check the user
    $parameters = array(':Username'=>$Username);
    $sth = $pdo->prepare('SELECT KlantNr, Inlognaam, Wachtwoord, Salt, Level FROM klanten WHERE Inlognaam = :Username LIMIT 1');
    $sth->execute($parameters);

    // Check if the username exists in the database
    if ($sth->rowCount() == 1) 
    {
        // Fetch the row data
        $row = $sth->fetch();
        
        // Hash the input password with the salt
        $password = hash('sha512', $password . $row['Salt']);

        // Check if the hashed password matches the one in the database
        if ($row['Wachtwoord'] == $password) 
        {
            // Get the user agent string
            $user_browser = $_SERVER['HTTP_USER_AGENT'];

            // Store user session data
            $_SESSION['user_id'] = $row['KlantNr'];
            $_SESSION['username'] = $Username;
            $_SESSION['level'] = $row['Level'];
            $_SESSION['login_string'] = hash('sha512', $password . $user_browser);

            // Login successful
            return true;
        } 
        else 
        {
            // Password incorrect
            return false;
        }
    }
    else
    {
        // Username does not exist
        return false;
    }
}

// Begin page
$Error = NULL;

if(isset($_POST['Inloggen']))
{
    // Handle form submission
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];
	echo"<br>";

    if(login($Username, $Password, $pdo))
    {
        // Successful login
        echo '<div class="login-container"><div class="success-message">U bent succesvol ingelogd</div></div>';

    }
    else
    {
        // Failed login
        $Error = "De Inlognaam of het Wachtwoord is onjuist.";
        require('./Forms/InloggenForm.php');
    }
}

else
{
    // Display form
    require('./Forms/InloggenForm.php');
}
?>
