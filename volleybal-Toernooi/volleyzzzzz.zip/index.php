<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rijschool DriveSmart</title>
</head>
<body>
		<?php
			require('includes/header.php');
		?>
<?php
    if(isset($_GET["PaginaNr"])) {
        $PaginaNr = $_GET["PaginaNr"];
        
        switch($PaginaNr) {
            case 1: 
                require('../drivesmart/pages/Agenda.php');
                break;

            case 2:
                require('../drivesmart/pages/LeerlingenOverzicht.php');
                break;

            case 3: 
                require('../drivesmart/pages/LessenOverzicht.php');
                break;

            case 4: 
                require('../drivesmart/pages/Plannen.php');
                break;

            case 5: 
                require('../drivesmart/pages/Verslag.php');
                break;

                case 6: 
                    require('../drivesmart/Forms/registrerenform.php');
                    break;


            case 7: 
                require('pages/Inloggen.php');
                break;

                default:
                break;
                }
            }
            require ('includes/footer.php');
?>
</body>
</html>