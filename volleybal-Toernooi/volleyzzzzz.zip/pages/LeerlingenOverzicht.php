<?php
// Voeg de config.php toe voor databaseverbinding
include('config.php');

// Functie om alle leerlingen op te halen
function getLeerlingen() {
    global $pdo;
    $sql = "SELECT id, voornaam, tussenvoegsel, achternaam FROM gebruikers WHERE rol = 'leerling'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Haal alle leerlingen op
$leerlingen = getLeerlingen();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leerlingen Overzicht</title>
    <style>
        .leerling-info {
            display: none;
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
        .leerling-item {
            cursor: pointer;
            padding: 5px;
            margin: 5px 0;
            border: 1px solid #ccc;
            background-color: #f0f0f0;
        }
        .leerling-item:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>

<h1>Leerlingen Overzicht</h1>

<!-- Lijst van leerlingen -->
<ul>
    <?php foreach ($leerlingen as $leerling): ?>
        <li class="leerling-item" onclick="showLeerlingInfo(<?php echo $leerling['id']; ?>)">
            <?php echo $leerling['voornaam'] . ' ' . $leerling['tussenvoegsel'] . ' ' . $leerling['achternaam']; ?>
        </li>
        
        <!-- Verborgen informatie van de leerling -->
        <div id="leerling-info-<?php echo $leerling['id']; ?>" class="leerling-info">
            <?php
            // Haal de extra gegevens van de leerling op (zoals adres, telefoonnummer, etc.)
            $sql = "SELECT * FROM gebruikers WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':id', $leerling['id'], PDO::PARAM_INT);
            $stmt->execute();
            $leerlingData = $stmt->fetch(PDO::FETCH_ASSOC);
            ?>
            <strong>Telefoonnummer:</strong> <?php echo $leerlingData['telefoonnr']; ?><br>
            <strong>Email:</strong> <?php echo $leerlingData['email']; ?><br>
            <strong>Adres:</strong> <?php echo $leerlingData['straatnaam'] . ' ' . $leerlingData['huisnr'] . ', ' . $leerlingData['postcode'] . ' ' . $leerlingData['woonplaats']; ?><br>
            <strong>Rijlessen over:</strong> <!-- Dit kun je aanvullen met een query voor het aantal resterende lessen, als je dat hebt --> <br>
        </div>
    <?php endforeach; ?>
</ul>

<script>
    // Functie om leerlinginformatie te tonen
    function showLeerlingInfo(id) {
        var infoDiv = document.getElementById('leerling-info-' + id);
        if (infoDiv.style.display === "none" || infoDiv.style.display === "") {
            infoDiv.style.display = "block";
        } else {
            infoDiv.style.display = "none";
        }
    }
</script>

</body>
</html>
