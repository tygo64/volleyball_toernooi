<?php
// Databaseconfiguratie
$host = '127.0.0.1'; // Je host (meestal localhost)
$dbname = 'drivesmart'; // Je databasenaam
$username = 'root'; // Je databasegebruikersnaam
$password = ''; // Je databasewachtwoord (leeg voor lokale MySQL)

// Maak de PDO-verbinding
try {
    // Verbinding maken met de database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Zet de foutmodus naar uitzondering
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Optioneel: verbinding testen door een eenvoudige query uit te voeren
    $pdo->query("SELECT 1");  // Dit is een simpele testquery

    // Als de verbinding succesvol is, kun je hier een logbericht toevoegen (optioneel)
    // echo "Verbinding succesvol!";
    
} catch (PDOException $e) {
    // Als er een fout optreedt, wordt deze exception opgevangen en wordt het bericht getoond
    die("Databaseverbinding mislukt: " . $e->getMessage());
}
?>
