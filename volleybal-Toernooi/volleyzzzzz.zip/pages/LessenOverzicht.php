<?php
// Voeg de config.php toe voor databaseverbinding
include('config.php');

// Functie om alle afgeronde lessen op te halen
function getAfgerondeLessen() {
    global $pdo;
    // Haal alle lessen op die afgerond zijn (bijvoorbeeld door naar lesverslag te kijken)
    $sql = "SELECT lb.id, lb.datum, lb.starttijd, lb.eindtijd, g.voornaam, g.tussenvoegsel, g.achternaam 
            FROM lesblokken lb
            JOIN gebruikers g ON lb.leerling_id = g.id
            WHERE lb.lesverslag IS NOT NULL"; // Dit filtert op afgeronde lessen (waar verslag aanwezig is)
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Haal alle afgeronde lessen op
$lessen = getAfgerondeLessen();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lessenoverzicht</title>
    <style>
        .les-info {
            display: none;
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
        .les-item {
            cursor: pointer;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            background-color: #f0f0f0;
        }
        .les-item:hover {
            background-color: #e0e0e0;
        }
        .verslag-btn {
            margin-top: 10px;
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        .verslag-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<h1>Lessenoverzicht</h1>

<!-- Lijst van afgeronde lessen -->
<ul>
    <?php foreach ($lessen as $les): ?>
        <li class="les-item" onclick="showLesInfo(<?php echo $les['id']; ?>)">
            <?php echo $les['datum'] . ' - ' . $les['starttijd'] . ' tot ' . $les['eindtijd'] . ' - ' . $les['voornaam'] . ' ' . $les['tussenvoegsel'] . ' ' . $les['achternaam']; ?>
        </li>
        
        <!-- Verborgen informatie over de les -->
        <div id="les-info-<?php echo $les['id']; ?>" class="les-info">
            <strong>Les ID:</strong> <?php echo $les['id']; ?><br>
            <strong>Datum:</strong> <?php echo $les['datum']; ?><br>
            <strong>Tijd:</strong> <?php echo $les['starttijd'] . ' - ' . $les['eindtijd']; ?><br>
            <strong>Leerling:</strong> <?php echo $les['voornaam'] . ' ' . $les['tussenvoegsel'] . ' ' . $les['achternaam']; ?><br>
            
            <!-- Verslag schrijven knop -->
            <form method="get" action="verslag.php">
                <input type="hidden" name="les_id" value="<?php echo $les['id']; ?>" />
                <button type="submit" class="verslag-btn">Verslag Schrijven</button>
            </form>
        </div>
    <?php endforeach; ?>
</ul>

<script>
    // Functie om lesinformatie te tonen
    function showLesInfo(id) {
        var infoDiv = document.getElementById('les-info-' + id);
        if (infoDiv.style.display === "none" || infoDiv.style.display === "") {
            infoDiv.style.display = "block";
        } else {
            infoDiv.style.display = "none";
        }
    }
</script>

</body>
</html>
