<?php  
require ('includes/DBconnection.php');
session_start();

// Haal de leerlingen op uit de database voor de dropdown
$sql_leerlingen = "SELECT id, voornaam, achternaam FROM gebruikers WHERE rol = 'leerling'";
$stmt_leerlingen = $conn->prepare($sql_leerlingen);
$stmt_leerlingen->execute();
$leerlingen = $stmt_leerlingen->fetchAll(PDO::FETCH_ASSOC);

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Retrieve form data
    $datum = $_POST['datum'];
    $starttijd = $_POST['starttijd'];
    $eindtijd = $_POST['eindtijd'];
    $id = $_POST['leerling'];

    // Store the form data in session for use in further pages or confirmation
    $_SESSION['datum'] = $datum;
    $_SESSION['starttijd'] = $starttijd;
    $_SESSION['eindtijd'] = $eindtijd;
    $_SESSION['leerling'] = $id;

    // SQL query to insert data into database
    $sql = "INSERT INTO lesblokken (datum, starttijd, eindtijd, id) VALUES (:datum, :starttijd, :eindtijd, :leerling)";

    // Prepare and execute the query
    try {
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':datum', $datum);
        $stmt->bindParam(':starttijd', $starttijd);
        $stmt->bindParam(':eindtijd', $eindtijd);
        $stmt->bindParam(':leerling', $id);

        // Execute the query
        $stmt->execute();
        
        // Redirect to a confirmation page or display a message
        header("Location: bevestiging.php");  // Verander dit naar de juiste pagina voor bevestiging
        exit; // Zorg ervoor dat de script stopt na de redirect
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<div class="login-container">
    <h2>Rijles Inplannen</h2>
    <form method="post" action="index.php?PaginaNr=5">
        <div class="input-group">
            <label for="datum">Datum van rijles</label>
            <input type="date" id="datum" name="datum" required>
        </div>

        <div class="input-group">
            <label for="starttijd">Starttijd</label>
            <input type="time" id="starttijd" name="starttijd" required>
        </div>

        <div class="input-group">
            <label for="eindtijd">Eindtijd</label>
            <input type="time" id="eindtijd" name="eindtijd" required>
        </div>

        <div class="input-group">
            <label for="leerling">Leerling</label>
            <select id="leerling" name="leerling" required>
                <option value="">Selecteer een leerling</option>
                <?php foreach ($leerlingen as $leerling): ?>
                    <option value="<?= $leerling['id'] ?>"><?= $leerling['voornaam'] . ' ' . $leerling['achternaam'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" name="submit">Rijles Inplannen</button>
    </form>
</div>
