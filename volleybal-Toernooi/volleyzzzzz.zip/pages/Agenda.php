<?php
require('includes/DBconnection.php');
session_start();

// Haal alle ingeplande rijlessen op
$sql = "SELECT l.datum, l.starttijd, l.eindtijd, g.voornaam, g.achternaam 
        FROM lesblokken l
        JOIN gebruikers g ON l.leerling_id = g.id
        ORDER BY l.datum ASC, l.starttijd ASC";

$stmt = $conn->prepare($sql);
$stmt->execute();
$lessen = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Organiseer lessen per datum
$agenda = [];
foreach ($lessen as $les) {
    $agenda[$les['datum']][] = $les;
}

?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <link rel="stylesheet" href="/stylesheets/agenda.css">
</head>
<body>
    <div class="container">
        <h2>Agenda</h2>
        
        <!-- Toon de agenda met ingeplande lessen -->
        <table class="agenda-table">
            <thead>
                <tr>
                    <th>Datum</th>
                    <th>Les Starttijd</th>
                    <th>Les Eindtijd</th>
                    <th>Leerling</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($agenda as $datum => $lessen_per_datum): ?>
                    <tr class="date-header">
                        <td colspan="4"><?= date('d-m-Y', strtotime($datum)) ?></td>
                    </tr>
                    <?php foreach ($lessen_per_datum as $les): ?>
                        <tr>
                            <td><?= date('d-m-Y', strtotime($les['datum'])) ?></td>
                            <td><?= date('H:i', strtotime($les['starttijd'])) ?></td>
                            <td><?= date('H:i', strtotime($les['eindtijd'])) ?></td>
                            <td><?= $les['voornaam'] . ' ' . $les['achternaam'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
