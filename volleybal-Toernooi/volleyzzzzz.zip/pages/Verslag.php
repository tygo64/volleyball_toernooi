<?php
// Voeg de config.php toe voor databaseverbinding
include('config.php');

// Functie om verslag op te slaan
function slaVerslagOp($lesID, $verslag) {
    global $pdo; // Gebruik de globale databaseverbinding

    try {
        // Bereid de SQL-query voor om het verslag op te slaan in de lesblokken tabel
        $sql = "UPDATE lesblokken SET lesverslag = :lesverslag WHERE id = :les_id";
        $stmt = $pdo->prepare($sql);

        // Bind de waarden
        $stmt->bindParam(':les_id', $lesID, PDO::PARAM_INT);
        $stmt->bindParam(':lesverslag', $verslag, PDO::PARAM_STR);

        // Voer de query uit
        $stmt->execute();

        return true;
    } catch (PDOException $e) {
        echo "Fout bij het opslaan van het verslag: " . $e->getMessage();
        return false;
    }
}

// Haal alle lesblokken op uit de database
function getLesblokken() {
    global $pdo;
    $sql = "SELECT id, datum, starttijd, eindtijd, leerling_id FROM lesblokken";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Verwerk het formulier bij een POST-verzoek
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Controleer of de benodigde gegevens aanwezig zijn in de POST-array
    if (isset($_POST['lesID']) && isset($_POST['verslag'])) {
        $lesID = $_POST['lesID']; // Les ID die je doorstuurt
        $verslag = $_POST['verslag']; // Verslag dat je hebt ingevuld

        // Roep de functie aan om het verslag op te slaan
        if (slaVerslagOp($lesID, $verslag)) {
            echo "Verslag succesvol opgeslagen!";
        } else {
            echo "Er is iets mis gegaan bij het opslaan van het verslag.";
        }
    } else {
        echo "Er ontbreken gegevens om het verslag op te slaan.";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verslag Schrijven</title>
</head>
<body>
    <h1>Schrijf een verslag voor de les</h1>

    <!-- Formulier voor verslag -->
    <form method="POST" action="">
        <label for="lesID">Selecteer les:</label>
        <select id="lesID" name="lesID" required>
            <option value="">Kies een les</option>
            <?php
            // Haal alle lesblokken op en vul de dropdown
            $lesblokken = getLesblokken();
            foreach ($lesblokken as $les) {
                // Haal de naam van de leerling op
                $leerling_id = $les['leerling_id'];
                $sql = "SELECT voornaam, achternaam FROM gebruikers WHERE id = :leerling_id";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':leerling_id', $leerling_id, PDO::PARAM_INT);
                $stmt->execute();
                $leerling = $stmt->fetch(PDO::FETCH_ASSOC);
                $les_naam = $leerling['voornaam'] . ' ' . $leerling['achternaam'];
                $les_datum = $les['datum'];
                $les_starttijd = $les['starttijd'];
                $les_eindtijd = $les['eindtijd'];

                // Vul de dropdown met lesgegevens
                echo "<option value='{$les['id']}'>
                        $les_naam - $les_datum $les_starttijd - $les_eindtijd
                      </option>";
            }
            ?>
        </select><br>
        
        <label for="verslag">Verslag:</label><br>
        <textarea id="verslag" name="verslag" rows="4" cols="50" required></textarea><br>
        
        <button type="submit">Verslag opslaan</button>
    </form>

</body>
</html>
