-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 15 jan 2025 om 11:03
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drivesmart`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `autos`
--

CREATE TABLE `autos` (
  `id` int(11) NOT NULL,
  `kenteken` int(45) NOT NULL,
  `merk` int(45) NOT NULL,
  `type` int(45) NOT NULL,
  `electrisch` tinyint(1) NOT NULL DEFAULT 0,
  `bouwjaar` int(11) NOT NULL,
  `opmerking` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `autos`
--

INSERT INTO `autos` (`id`, `kenteken`, `merk`, `type`, `electrisch`, `bouwjaar`, `opmerking`) VALUES
(0, 0, 0, 0, 1, 0, ''),
(0, 0, 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `gebruikers`
--

CREATE TABLE `gebruikers` (
  `id` int(11) NOT NULL,
  `voornaam` varchar(45) NOT NULL,
  `tussenvoegsel` varchar(45) NOT NULL,
  `achternaam` varchar(45) NOT NULL,
  `straatnaam` varchar(45) NOT NULL,
  `huisnr` varchar(45) NOT NULL,
  `postcode` varchar(45) NOT NULL,
  `woonplaats` varchar(45) NOT NULL,
  `telefoonnr` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `gebruikersnaam` varchar(45) NOT NULL,
  `wachtwoord` varchar(200) NOT NULL,
  `rol` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `gebruikers`
--

INSERT INTO `gebruikers` (`id`, `voornaam`, `tussenvoegsel`, `achternaam`, `straatnaam`, `huisnr`, `postcode`, `woonplaats`, `telefoonnr`, `email`, `gebruikersnaam`, `wachtwoord`, `rol`) VALUES
(0, '', '', '', '', '', '', '', '', '', '', '', 'leerling'),
(0, '', '', '', '', '', '', '', '', '', '', '', 'instructeu'),
(0, '', '', '', '', '', '', '', '', '', '', '', 'eigenaar');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `leerling_strippenkaarten`
--

CREATE TABLE `leerling_strippenkaarten` (
  `id` int(11) NOT NULL,
  `strippenkaarten_id` int(11) NOT NULL,
  `gebruikers_id` int(11) NOT NULL,
  `lessen_restrerend` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `lesblokkeb`
--

CREATE TABLE `lesblokkeb` (
  `id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `starttijd` time NOT NULL,
  `eindtijd` time NOT NULL,
  `auto_id` int(11) NOT NULL,
  `instructeur_id` int(11) NOT NULL,
  `leerling_id` int(11) NOT NULL,
  `lesverslag` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `strippenkaarten`
--

CREATE TABLE `strippenkaarten` (
  `id` int(11) NOT NULL,
  `beschrijving` varchar(45) NOT NULL,
  `aantal_lessen` int(11) NOT NULL,
  `prijs` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `strippenkaarten_les`
--

CREATE TABLE `strippenkaarten_les` (
  `id` int(11) NOT NULL,
  `leerling _strippenkaart_id` int(11) NOT NULL,
  `lesblok_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
