<!-- 
	Opdracht PM11 STAP 1 : Film Toevoegen 
	Maak hier het formulier waarmee je een film kan toevoegen aan de database. Let op: dit formulier komt dus overeen met de velden uit de database tabel Films
-->
<link rel="stylesheet" href="./style.css">
	
<h1>Boot Toevoegen</h1>
	<form name="BootToevoegenFormulier" action="" method="post">
		<label for="Naam">Naam:</label>
		<input type="text" id="Naam" name="Naam" value="<?php echo $Naam; ?>"/><?php echo $NaamErr; ?>
		<br />
		<label for="Omschrijving">Omschrijving:</label><br />
		<textarea rows="4" cols="50" id="Omschrijving" name="Omschrijving"><?php echo $Omschrijving; ?></textarea>
		<?php echo $DescErr; ?>
		<br />		
		<label for="Bouwjaar">Bouwjaar:</label>
		<input type="text" id="Bouwjaar" name="Bouwjaar" maxlength="4" value="<?php echo $Bouwjaar; ?>" /><?php echo $DurErr; ?>
		<br />
		<?php
		$db = ConnectDB();
		try {
    $query = $db->prepare("SELECT * FROM Boten");
    $query->execute();
} catch(PDOException $e) {
    die("Error!: " . $e->getMessage());
}
echo '<label for="Merk">Type:</label>';
echo '<select id="Merk" name="Merk">';
while ($data = $query->fetch(PDO::FETCH_ASSOC)) {
    echo '<option value="'.$data['BootNr'].'">'.$data['Merk'].'  <br>';
}
echo '</select>';
		 ?> 
		<br />		
		<label for="Capaciteit">Capaciteit:</label>
		<select id="C	apaciteit" name="Capaciteit">
			<option value="6" <?php if($Capaciteit=="6"){echo "selected";} ?>>6</option>
			<option value="12" <?php if($Capaciteit=="12"){echo "selected";} ?>>12</option>
			<option value="16" <?php if($Capaciteit=="16"){echo "selected";} ?>>16</option>
			<option value="18" <?php if($Capaciteit=="18"){echo "selected";} ?>>18</option>
		</select> 
		<br />
		<label for="Plaatje">Plaatje:</label>
		<input type="file" id="Plaatje" name="Plaatje" value="<?php echo $Plaatje; ?>" />
		<br />

		<label for="Prijs">Prijs:</label>
		<input type="text" id="Prijs" name="Prijs" value="<?php echo $Prijs; ?>" />
		<?php echo $PrijsErr; ?>
		<br />
		<br />
		<!-- query voor soorten boten -->
		 <?php $db = ConnectDB();
try {
    $query = $db->prepare("SELECT * FROM soorten_boten");
    $query->execute();
} catch(PDOException $e) {
    die("Error!: " . $e->getMessage());
}
echo '<label for="SoortBootNr">Type:</label>';
echo '<select id="SoortBootNr" name="SoortBootNr">';
while ($data = $query->fetch(PDO::FETCH_ASSOC)) {
    echo '<option value="'.$data['SoortBootNr'].'">'.$data['Naam'].'<br>';
}
echo '</select>';
		 ?>
		 <?php
try {
    $query = $db->prepare("SELECT * FROM locatie");
    $query->execute();
} catch(PDOException $e) {
    die("Error!: " . $e->getMessage());
}
echo '<label for="LocatieNr">Locatie:</label>';
echo '<select id="LocatieNr" name="LocatieNr">';
while ($data = $query->fetch(PDO::FETCH_ASSOC)) {
    echo '<option value="'.$data['LocatieNr'].'">'.$data['Naam'].'<br>';
}
echo '</select>';?>
		<br />		
		<label for="Status">Status:</label>
		<select id="Status" name="Status">
			<option value="Verwacht" <?php if($Status=="Verwacht"){echo "selected";} ?>>Verwacht</option>
			<option value="Beschikbaarheid" <?php if($Status=="Beschikbaarheid"){echo "selected";} ?>>Beschikbaarheid</option>
		</select> 
		<br />
		<label for="Lengte">Lengte:</label>
		<input type="text" id="Lengte" name="Lengte" value="<?php echo $Lengte; ?>" />
		<br />		
		<input type="submit" name="Toevoegen" value="Toevoegen!" />
	</form>
	<br />
