<?php
// beveiliging pagina voor niet geautoriseerde bezoekers
if(LoginCheck($pdo))
{
	// user is ingelogd
	if($_SESSION['level'] >= 5) //pagina alleen zichtbaar voor level 5 of hoger
	{
		
	//-------------code---------------//	
		
		//init fields
		$Naam = $Merk = $Bouwjaar = $Omschrijving = $Prijs = $Plaatje = $Status = $SoortBootNr = $LocatieNr = $Capaciteit = $Lengte = NULL;

		//init error fields
		$NaamErr = $DescErr = $DurErr = $SoortBootNrErr = $LocatieNrErr = $PrijsErr= NULL;


		if(isset($_POST['Toevoegen']))
		{	
			$CheckOnErrors = false; // hulpvariabele voor het valideren van het formulier
				
			$Naam = $_POST["Naam"];
			$Merk = $_POST["Merk"];
			$Bouwjaar = $_POST['Bouwjaar'];
			$Omschrijving = $_POST['Omschrijving'];
			$Prijs = $_POST['Prijs'];
			$Plaatje = $_POST['Plaatje'];
			$Status = $_POST['Status'];
			$SoortBootNr = $_POST['SoortBootNr'];
			$LocatieNr = $_POST['LocatieNr'];
			$Capaciteit = $_POST['Capaciteit'];
			$Lengte = $_POST['Lengte'];

			if($CheckOnErrors)
			{
				//er zijn fouten geconstateerd
				require('./Modules/catalogus.php');
			}
			else
			{
			
				//query opbouwen
				$parameters = array(
							':Naam'=>$Naam,
							':Merk'=>$Merk,
							':Bouwjaar'=>$Bouwjaar,
							':Omschrijving'=>$Omschrijving,
							':Prijs'=>$Prijs,
							':Plaatje'=>$Plaatje,
							':Status'=>$Status,
							':SoortBootNr'=>$SoortBootNr,
							':LocatieNr'=>$LocatieNr,
							':Capaciteit'=>$Capaciteit,
							':Lengte'=>$Lengte);

				$sth = $pdo->prepare('INSERT INTO boten (Naam, Merk, Bouwjaar, Omschrijving, Prijs, Plaatje, Status, SoortBootNr, LocatieNr, Capaciteit, Lengte) VALUES (:Naam, :Merk, :Bouwjaar, :Omschrijving, :Prijs, :Plaatje, :Status, :SoortBootNr, :LocatieNr, :Capaciteit, :Lengte)');
	
				$sth->execute($parameters);
				
				echo "De Boot is toegevoegd aan de Database.";
				RedirectNaarPagina(3,7);
			}
		}
		else
		{
			require('./Forms/BootToevoegenForm.php');
		}
	}
	else
	{
		//user heeft niet het correcte level
		echo 'U heeft niet de juiste bevoegdheid voor deze pagina.';
		RedirectNaarPagina(5);//redirect naar home
	}
}
else
{
	//user is niet ingelogd
	RedirectNaarPagina(NULL,98);//instant redirect naar inlogpagina
}
?>