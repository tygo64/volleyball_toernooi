<?php

// Change die with ...? when logged in clicked boat and location will be saved
// when logged from this site you will be redirected to reservation with the save info

$pdo = ConnectDB();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Store the current page URL in the session for redirection after login
    die("You must be logged in to view this page. <a href='index.php?pageNr=98'>Login here</a>");
}

// Validate and fetch boat details
if (isset($_GET['boatID'])) {
    $boatID = (int)$_GET['boatID'];

    try {

        // Look for code Structure between boats.php and reservations.php 

        $query = $pdo->prepare("SELECT * FROM boat WHERE boatID = :boatID");
        $query->bindParam(':boatID', $boatID, PDO::PARAM_INT);
        $query->execute();
        $boat = $query->fetch(PDO::FETCH_ASSOC);

        if (!$boat) {
            die("Boat not found.");
        }

        // Fetch reserved dates for the boat
        $reservedDatesQuery = $pdo->prepare("
            SELECT DISTINCT dateStart, dateEnd FROM reservation
            WHERE boatID = :boatID AND status = 'Active'
        ");
        $reservedDatesQuery->execute([':boatID' => $boatID]);
        $reservedDates = $reservedDatesQuery->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die("Error fetching boat details: " . $e->getMessage());
    }
} else {
    die("No boat selected for reservation.");
}

$user = $_SESSION['user'];

// form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $boatID = $_POST['boatID'];
    $customerID = $_POST['customerID'];
    $dateStart = $_POST['dateStart'];
    $dateEnd = !empty($_POST['dateEnd']) ? $_POST['dateEnd'] : $_POST['dateStart']; 
    $timeSlot = $_POST['timeSlot'];

    // Validate dates
    $currentDate = date('Y-m-d');
    if ($dateStart < $currentDate || $dateEnd < $dateStart) {
        die("Invalid date selection. You cannot reserve in the past or set an end date earlier than the start date.");
    }

    // Check availability
    $availabilityQuery = $pdo->prepare("
        SELECT COUNT(*) FROM reservation
        WHERE boatID = :boatID
        AND ((dateStart <= :dateEnd AND dateEnd >= :dateStart) AND timeSlot = :timeSlot)
    ");
    $availabilityQuery->execute([
        ':boatID' => $boatID,
        ':dateStart' => $dateStart,
        ':dateEnd' => $dateEnd,
        ':timeSlot' => $timeSlot
    ]);
    $conflicts = $availabilityQuery->fetchColumn();

    if ($conflicts > 0) {
        die("The selected time slot is already reserved. Please choose a different time slot or date.");
    }

    // Insert reservation
    $insertQuery = $pdo->prepare("
        INSERT INTO reservation (boatID, customerID, dateStart, dateEnd, timeSlot)
        VALUES (:boatID, :customerID, :dateStart, :dateEnd, :timeSlot)
    ");
    $insertQuery->execute([
        ':boatID' => $boatID,
        ':customerID' => $customerID,
        ':dateStart' => $dateStart,
        ':dateEnd' => $dateEnd,
        ':timeSlot' => $timeSlot
    ]);

    RedirectToPage(4, 4);

    // Refresh page were "Reservation is succesful placed" stands
    // Refresh page 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserve a Boat</title>
    <!-- <link rel="stylesheet" href="stylesheets/reservation.css"> -->
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: #333;
        }

        #top-text {
            margin-top: 5%;
        }

        h1, h2 {
            padding: 10px;
            text-align: center;
            color: #0056b3;
        }

        p {
            text-align: center;
            line-height: 1.6;
        }

        /* Container */
        .container {
            max-width: 800px;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column; /* Stack elements vertically */
            align-items: center;   /* Center elements horizontally */
            margin-top: 20px;
        }

        label {
            font-weight: bold;
            margin-bottom: 8px;
            width: 100%; /* Align label with input */
            text-align: center; /* Align text to the left */
        }

        input[type="date"], select, input[type="submit"] {
            width: 50%;
            max-width: 400px; /* Optional: Prevent elements from becoming too wide */
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #0056b3;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #003d80;
        }
    </style>
    <script>
        // Disable reserved dates
        const reservedDates = <?php echo json_encode($reservedDates); ?>;
        function disableReservedDates(input) {
            const selectedDate = input.value;
            for (let date of reservedDates) {
                if (selectedDate >= date.dateStart && selectedDate <= date.dateEnd) {
                    alert("This date is unavailable. Please choose another date.");
                    input.value = "";
                    break;
                }
            }
        }
    </script>
</head>
<body>
    <h1 id="top-text">Boat Information</h1>
    <p><strong>Boat Name:</strong> <?php echo htmlspecialchars($boat['name']); ?></p>
    <p><strong>Brand:</strong> <?php echo htmlspecialchars($boat['brand']); ?></p>
    <p><strong>Capacity:</strong> <?php echo htmlspecialchars($boat['capacity']); ?> people</p>
    <p><strong>Price per Hour:</strong> €<?php echo number_format($boat['cph'], 2, ',', '.'); ?></p>

    <h2>Personal Information</h2>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($user['firstName'] . ' ' . $user['lastName']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>

    <form name="reservation_process" action="" method="POST">
        <input type="hidden" name="boatID" value="<?php echo htmlspecialchars($boatID); ?>">
        <input type="hidden" name="customerID" value="<?php echo htmlspecialchars($user['customerID']); ?>">

        <label for="dateStart">Select Start Date:</label><br>
        <input type="date" id="dateStart" name="dateStart" min="<?php echo date('Y-m-d'); ?>" oninput="disableReservedDates(this)" required><br><br>

        <label for="dateEnd">Select End Date (Optional):</label><br>
        <input type="date" id="dateEnd" name="dateEnd" min="<?php echo date('Y-m-d'); ?>" oninput="disableReservedDates(this)"><br><br>

        <label for="timeSlot">Select Time Slot:</label><br>
        <select id="timeSlot" name="timeSlot" required>
            <option value="Morning">Morning (09:00 - 12:00)</option>
            <option value="Afternoon">Afternoon (13:00 - 18:00)</option>
            <option value="Full Day">Full Day</option>
        </select><br><br>

        <input type="submit" value="Reserve">
    </form>
</body>
</html>
