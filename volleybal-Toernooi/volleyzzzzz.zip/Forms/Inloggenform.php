<div class="login-container">
    <h2>Inloggen</h2>
    <?php if(isset($Error)): ?>
        <div class="error-message"><?= $Error ?></div>
    <?php endif; ?>
    <form method="post" action="">
        <div class="form-group">
            <label for="username">Gebruikersnaam:</label>
            <input type="text" id="username" name="Username" required>
        </div>
        <div class="form-group">
            <label for="password">Wachtwoord:</label>
            <input type="password" id="password" name="Password" required>
        </div>
        <div class="form-group">
            <button type="submit" name="Inloggen" class="login-button">Inloggen</button>
			<h3>Heeft u nog geen Account? Registreer dan <a href="index.php?PaginaNr=6">hier</h3></a>
        </div>
    </form>
</div>
