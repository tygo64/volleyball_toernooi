<?php
// Zorg ervoor dat de juiste bestandslocatie voor config.php wordt gebruikt
include('../pages/config.php'); // Pas het pad aan als config.php in een andere map staat

// Fouten initialisatie
$FnameErr = $LnameErr = $TelErr = $MailErr = $UserErr = $PassErr = $RePassErr = "";

// Variabelen initialiseren
$Voornaam = $Achternaam = $Telefoonnr = $Email = $Gebruikersnaam = "";

// Controleer of het formulier is ingediend
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verkrijg formuliergegevens
    $Voornaam = $_POST['FirstName'];
    $Achternaam = $_POST['LastName'];
    $Telefoonnr = $_POST['TelNr'];
    $Email = $_POST['Email'];
    $Gebruikersnaam = $_POST['Username'];
    $Password = $_POST['Password'];
    $RetypePassword = $_POST['RetypePassword'];

    // Foutcontrole
    if (empty($Voornaam)) {
        $FnameErr = "Voornaam is verplicht";
    }
    if (empty($Achternaam)) {
        $LnameErr = "Achternaam is verplicht";
    }
    if (empty($Telefoonnr)) {
        $TelErr = "Telefoonnummer is verplicht";
    }
    if (empty($Email)) {
        $MailErr = "E-mail is verplicht";
    }
    if (empty($Gebruikersnaam)) {
        $UserErr = "Gebruikersnaam is verplicht";
    }
    if (empty($Password)) {
        $PassErr = "Wachtwoord is verplicht";
    }
    if ($Password != $RetypePassword) {
        $RePassErr = "Wachtwoorden komen niet overeen";
    }

    // Als geen fouten zijn, sla gegevens op in de database
    if (empty($FnameErr) && empty($LnameErr) && empty($TelErr) && empty($MailErr) && empty($UserErr) && empty($PassErr) && empty($RePassErr)) {
        // Encrypt wachtwoord voor veiligheid
        $hashedPassword = password_hash($Password, PASSWORD_DEFAULT);

        try {
            // SQL-query om gegevens op te slaan
            $sql = "INSERT INTO gebruikers (voornaam, achternaam, telefoonnr, email, gebruikersnaam, wachtwoord, rol) VALUES (:voornaam, :achternaam, :telefoonnr, :email, :gebruikersnaam, :wachtwoord, 'leerling')";
            
            $stmt = $pdo->prepare($sql);
            
            // Bind waarden
            $stmt->bindParam(':voornaam', $Voornaam);
            $stmt->bindParam(':achternaam', $Achternaam);
            $stmt->bindParam(':telefoonnr', $Telefoonnr);
            $stmt->bindParam(':email', $Email);
            $stmt->bindParam(':gebruikersnaam', $Gebruikersnaam);
            $stmt->bindParam(':wachtwoord', $hashedPassword);

            // Execute the statement and check for errors
            if ($stmt->execute()) {
                echo "Registratie succesvol!";
            } else {
                echo "Er is iets mis gegaan met de registratie.";
            }
        } catch (PDOException $e) {
            echo "Fout bij het opslaan van gegevens: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registreren</title>
</head>
<body>

<h1>Registreren</h1>

<form name="RegistratieFormulier" action="" method="post">
    <label for="FirstName">Voornaam:</label>
    <input type="text" id="FirstName" name="FirstName" value="<?php echo $Voornaam; ?>"/><?php echo $FnameErr; ?><br />
    
    <label for="LastName">Achternaam:</label>
    <input type="text" id="LastName" name="LastName" value="<?php echo $Achternaam; ?>" /><?php echo $LnameErr; ?><br />  
    
    <label for="TelNr">Telefoon nr.:</label>
    <input type="text" id="TelNr" name="TelNr" value="<?php echo $Telefoonnr; ?>" /><?php echo $TelErr; ?><br />
    
    <label for="Email">E-mail:</label>
    <input type="text" id="Email" name="Email" value="<?php echo $Email; ?>" /><?php echo $MailErr; ?><br />
    
    <label for="Username">Gewenste Gebruikersnaam:</label>
    <input type="text" id="Username" name="Username" value="<?php echo $Gebruikersnaam; ?>" /><?php echo $UserErr; ?><br />
    
    <label for="Password">Wachtwoord:</label>
    <input type="password" id="Password" name="Password" /><?php echo $PassErr; ?><br />
    
    <label for="RetypePassword">Herhaal Wachtwoord:</label>
    <input type="password" id="RetypePassword" name="RetypePassword" /><?php echo $RePassErr; ?><br />
    
    <input type="submit" name="Registreren" value="Registreer!" />
</form>

</body>
</html>
