<link rel="stylesheet" href="/stylesheets/header_footer.css">

<footer>
        <div class="social-footer">
            <a> 2025 DriveSmart</a>
        </div>
    </footer>