<link rel="stylesheet" href="/stylesheets/header_footer.css">

<header>
        <div class="logo">
            <img src="" alt="Logo" width="50" height="50">
        </div>
        <nav>
            <ul>
              <li><a href="index.php?PaginaNr=1">Agenda</a></li>
              <li><a href="index.php?PaginaNr=2">Leerlingen</a></li>
             <li><a href="index.php?PaginaNr=3">Lessen</a></li>
          <li><a href="index.php?PaginaNr=4">Plannen</a></li>
    <li><a href="index.php?PaginaNr=5">Verslag</a></li>
    <li><a href="index.php?PaginaNr=6">Registeren</a></li>
    <li><a href="index.php?PaginaNr=7">Login</a></li>
            </ul>
        </nav>

    </header>